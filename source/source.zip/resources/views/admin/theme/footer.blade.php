<div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; 2017-2018 <a style="cursor: pointer;">SSFS</a>.</strong> All rights
    reserved.