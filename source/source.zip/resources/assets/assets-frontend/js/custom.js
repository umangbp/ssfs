$(document).ready(function(){


	/*$('.our-vision-list li').click(function(){
		$(this).find('div').slideToggle();
	})*/

});