<?php $__env->startSection('content'); ?>
	
	
	<section class="content-header">
	  <h1>
	    Settings
	    <small>Update</small>
	  </h1>
	  <ol class="breadcrumb">
	    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
	    <li><a href="#">Settings</a></li>
	  </ol>
	</section>

	<!-- Main content -->
    <section class="content">
	    <div class="row">
	       	<div class="col-md-12">
	          	<div class="box box-info">
	            	<div class="box-body pad">
	              
		            	<?php if(session('message')): ?>
						    <div class="alert alert-success">
						    	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						        <span><?php echo e(session('message')); ?></span>
						    </div>
						<?php endif; ?>

						<?php echo e(Form::open(['route' => ['settings.update'], 'method' => 'POST'])); ?>

						

						<?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
								    	
								    	<?php echo e(Form::label('', $setting->label, ['class' => ''])); ?>


								    	<?php if($setting->field_type == 'textbox'): ?>

								    		<?php echo e(Form::text($setting->name, $setting->value,['class' => 'form-control', 'placeholder' => 'Please Enter '.$setting->label])); ?>


								    	<?php elseif($setting->field_type == 'number'): ?>

								    		<?php echo e(Form::number($setting->name, $setting->value,['class' => 'form-control', 'placeholder' => 'Please Enter '.$setting->label])); ?>


								    	<?php elseif($setting->field_type == 'textarea'): ?>

								    		<?php echo e(Form::textarea($setting->name, $setting->value, ['class' => 'form-control'])); ?>


								    	<?php else: ?> 


								    	<?php endif; ?>

										<div class="err-block">
											<span class="text-danger"><?php echo e($errors->first($setting->name)); ?></span>
										</div>
									</div>
								</div>
							</div>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<div class="row pad-top pad-bottom">
							<div class="col-md-6">
								<button type="submit" class="btn btn-success"><i class="fa fa-check"></i> Update</button>
								<a href="<?php echo e(route('ssfs.admin.dashboard')); ?>" class="btn btn-danger" style="margin-left:10px"><i class="fa fa-close"></i> Cancel</a>
							</div>
						</div>
						
						<?php echo e(Form::close()); ?>


					</div>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.theme.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>