<div class="tnit-banner">
    <!--Banner Slider Start-->
    <div id="tnit-banner-slider" class="owl-carousel">
        
        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">
            
            <img src="<?php echo e($banner->banner_image); ?>" alt="" style="max-height: 700px">
            <!--Banner Caption Start-->
             <div class="banner-caption">
                <div class="container">
                    <h2><?php echo e($banner->banner_text); ?></h2>
                     <strong><?php echo e($banner->banner_sub_text); ?></strong>
                </div>
             </div><!--Banner Caption End-->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div><!--Banner Slider End-->
</div>

