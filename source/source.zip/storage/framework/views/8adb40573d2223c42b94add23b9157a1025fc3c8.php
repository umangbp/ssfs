<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SSFS</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  
  <link rel="stylesheet" type="text/css" href="<?php echo e(mix('admin/css/all.css')); ?>">

  

  
  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">

  <script src="<?php echo e(asset('admin/bower_components/ckeditor/ckeditor.js')); ?>"></script>        


</head>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
    
    <header class="main-header">
      <?php echo $__env->make('admin.theme.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>

    <!-- Left side column. contains the logo and sidebar -->
    <aside class="main-sidebar">
      <?php echo $__env->make('admin.theme.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <?php echo $__env->yieldContent('content'); ?>
    </div>

    <footer class="main-footer">
      <?php echo $__env->make('admin.theme.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </footer>

  </div>
<!-- ./wrapper -->


<script src="<?php echo e(mix('admin/js/all.js')); ?>"></script>

<script type="text/javascript">

  if($('#content-editor').val() !== undefined){
    CKEDITOR.replace( 'content-editor' ).config.allowedContent = true;;
  }

</script>

<script type="text/javascript">

  if($('#short_desc-editor').val() !== undefined){
    CKEDITOR.replace('short_desc-editor').config.allowedContent = true;;
  }

  if($('#description-editor').val() !== undefined){
    CKEDITOR.replace('description-editor').config.allowedContent = true;;  
  }
  
</script>

</body>
</html>
