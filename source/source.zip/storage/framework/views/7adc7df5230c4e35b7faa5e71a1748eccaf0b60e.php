<?php $__env->startSection('content'); ?>
	
	
	<section class="content-header">
	  <h1>
	    Career
	    <small>Edit</small>
	  </h1>
	  <ol class="breadcrumb">
	    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
	    <li><a href="#">Careers</a></li>
	    <li><a>Edit</a></li>
	  </ol>
	</section>

	<!-- Main content -->
    <section class="content">
	    <div class="row">
	       	<div class="col-md-12">
	          	<div class="box box-info">
	            	<div class="box-body pad">
	              
		            	<?php if(session('invalid_file')): ?>
						    <div class="alert alert-danger">
						    	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						        <span><?php echo e(session('invalid_file')); ?></span>
						    </div>
						<?php endif; ?>

						<?php if(session('invalid_file')): ?>
						    <div class="alert alert-danger">
						    	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
						        <span><?php echo e(session('invalid_file')); ?></span>
						    </div>
						<?php endif; ?>

						<?php echo e(Form::model($career,['route' => ['careers.update', $career->id], 'method' => 'PUT'])); ?>

						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
							    	
							    	<?php echo e(Form::label('job_title_label', 'Job Title', ['class' => ''])); ?>

							    	<?php echo e(Form::text('job_title',null,['class' => 'form-control', 'placeholder' => 'Please Enter Job Title'])); ?>

									<div class="err-block">
										<span class="text-danger"><?php echo e($errors->first('job_title')); ?></span>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group"> 	
							    	<?php echo e(Form::label('job_description_label', 'Job Description', ['class' => ''])); ?>

							    	<?php echo e(Form::text('job_description',null,['class' => 'form-control', 'placeholder' => 'Please Enter Job Description'])); ?>


							    	<div class="err-block">
										<span class="text-danger"><?php echo e($errors->first('job_description')); ?></span>
									</div>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<?php echo e(Form::label('job_location_label', 'Job Location', ['class' => ''])); ?>

								<?php echo e(Form::text('job_location',null,['class' => 'form-control', 'placeholder' => 'Please Enter Job Location'])); ?>	

								<div class="err-block">
										<span class="text-danger"><?php echo e($errors->first('job_location')); ?></span>
									</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-2" style="padding-top: 10px;">
								<?php echo e(Form::label('status_career', 'Status', ['class' => ''])); ?>

								<?php echo e(Form::select('status',['0'=>'in-active', '1' => 'active'], $career->status, ['class'=> 'form-control'])); ?>	<div class="err-block">
										<span class="text-danger"><?php echo e($errors->first('status')); ?></span>
									</div>							
							</div>
						</div>
						<div class="row pad-top pad-bottom">
							<div class="col-md-6">
								<button type="submit" class="btn btn-success"><i class="fa fa-check"></i> Update</button>
								<a href="<?php echo e(route('careers.list')); ?>" class="btn btn-danger" style="margin-left:10px"><i class="fa fa-close"></i> Cancel</a>
							</div>
						</div>
						
						<?php echo e(Form::close()); ?>


					</div>
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.theme.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>