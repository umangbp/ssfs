<?php $__env->startSection('inner-banner'); ?>
	
	<!--Inner Banner Content Start-->
    <div class="tnit-inner-banner" id="tinit-career-banner">
      <div class="container">
        <div class="row">
          <div class="col-md-4 col-sm-3 col-xs-12">
            
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12">
            <h2>Job Openings</h2>
          </div>
          <div class="col-md-4 col-sm-3 col-xs-12">
            
          </div>
        </div>
      </div>
    </div><!--Inner Banner Content End-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
  
  <section class="tnit-career-section pd-tb70">
      <div class="container">
        <div class="tnit-heading-outer text-center">
            <h2>WE ARE HIRING</h2>
            <span class="small">-  Join our team   -</span>
        </div>
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
              <div>
                <p class="join-us-description">It's not only about doing your job when you are working with Sai Shraddha Foods Services, but it's about the beautiful journy that you live with us.</p><br/>
              </div>
              <div class="job-openings-block">
                
                <?php if(!empty($careers)): ?>

                <ul>
                  <?php $__currentLoopData = $careers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $career): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                      <div class="opening">
                        <span class="job-title"><?php echo e($career->job_title); ?></span>

                        <?php if($career->job_location !== ''): ?>
                        <span class="job-location"> - <?php echo e($career->job_location); ?></span>
                        <?php endif; ?>
                      </div>
                      <div class="job-description">
                        <p><?php echo e($career->job_description); ?></p>
                      </div>
                    </li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

                <div class="pd-tb70">
                  <p>If you are interested for any of the above openings, Please <a href="<?php echo e(route('contact-us')); ?>">contact us</a> on our contact details available on contact us page</p>
                </div>

                <?php else: ?> 
                  <div class="text-center pd-tb70">
                    <h3>Sorry.... Currently we don't have any openings</h3>
                  </div>
                <?php endif; ?>

              </div>
          </div>
        </div>
      </div>
  </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>