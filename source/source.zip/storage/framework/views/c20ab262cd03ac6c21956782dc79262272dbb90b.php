<?php $__env->startSection('inner-banner'); ?>
	
	<!--Inner Banner Content Start-->
    <div class="tnit-inner-banner" id="tnit-services-banner">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <h2><?php echo e($service_details->title); ?></h2>
          </div>
        </div>
      </div>
    </div><!--Inner Banner Content End-->

<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>

<section class="tinit-service-section pd-tb70">
  <div class="container">
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="service-image">
            <figure class="tnit-service-thumb">
                 <img class="image-responsive" src="<?php echo e($service_details->image); ?>" alt="<?php echo e($service_details->title); ?>">
            </figure>  
          </div>
          <div class="service-description">
              <?php echo $service_details->description; ?>

            </div>
        </div>
    </div>
  </div>
</section>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>