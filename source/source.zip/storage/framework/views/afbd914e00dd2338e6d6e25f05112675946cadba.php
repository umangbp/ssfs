<?php $__env->startSection('content'); ?>
	
	<!-- Content Header (Page header) -->
	<section class="content-header">
	  <h1>
	    Banner
	    <small>List</small>
	  </h1>
	  <ol class="breadcrumb">
	    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
	    <li><a href="#">Banners</a></li>
	  </ol>
	</section>

	<!-- Main content -->
    <section class="content">
      <div class="row">
      	<div class="col-md-12">
      		
      	</div>
        <div class="col-md-12">
          <div class="box box-info">
            <div class="box-body pad">
              
            	<?php if(session('message')): ?>
				    <div class="alert alert-success">
				    	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				        <span><?php echo e(session('message')); ?></span>
				    </div>
				<?php endif; ?>

				<?php if(session('err_message')): ?>
				    <div class="alert alert-success">
				    	<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
				        <span><?php echo e(session('err_message')); ?></span>
				    </div>
				<?php endif; ?>

              <!-- CMS Listing table -->  
            
            <div class="pull-right" style="padding-bottom: 20px;padding-top: 10px;">
      			<a class="btn btn-primary" href="<?php echo e(route('banner.create')); ?>"><i class="fa fa-file-image-o" aria-hidden="true"></i> Add New Banner</a>
      		</div>
      		<div>
              <table class="table table-bordered table-responsive cms-list">
              	<thead>
	              	<tr>
	              		<th>#</th>
	              		<th>Banner Text</th>
	              		<th>Sub Text</th>
	              		<th>Image</th>
	              		<th>Sequence No</th>
	              		<th>Status</th>
	              		<th>Actions</th>
	              	</tr>
              	</thead>
              	
              	<tbody>

	              	<?php if(isset($banners)): ?>

	              		<?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	              			<tr>
	              				<td><?php echo e($banner->id); ?></td>
	              				<td><?php echo e($banner->banner_text); ?></td>
	              				<td><?php echo e($banner->banner_sub_text); ?></td>
	              				<td class="text-center"><img src="<?php echo e($banner->banner_image); ?>" width="150px" height="80px" /></td>
	              				<td width="100" class="text-center"><?php echo e($banner->sequence_no); ?></td>
	              				<td width="100" class="text-center">
	              					<?php if($banner->status == 1): ?>
	              						<span class="badge badge-pill badge-primary">Active</span>
	              					<?php else: ?>
	              						<span class="badge badge-danger">Inactive</span>
	              					<?php endif; ?>
	              					
	              				</td>
	              				<td  width="110">
	              					<a class="btn btn-info" href="<?php echo e(URL('ssfs-admin/banners/'.$banner->id)); ?>"><i class="fa fa-edit"></i></a>
	              					<a class="btn btn-danger" href="<?php echo e(URL('ssfs-admin/banners/delete/'.$banner->id)); ?>"><i class="fa fa-trash"></i></a>
	              				</td>

	              			</tr>
	              		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

	              	<?php endif; ?>

	              	<?php if(empty($banners)): ?>
	              			<tr>
	              				<td  colspan="5" class="text-center"><span>No Banner Available</span></td>
	              			</tr>
	              	<?php endif; ?>
              	
              	</tbody>
              </table>
              </div>
            </div>
          </div>

        </div>
       
      </div>
    
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.theme.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>